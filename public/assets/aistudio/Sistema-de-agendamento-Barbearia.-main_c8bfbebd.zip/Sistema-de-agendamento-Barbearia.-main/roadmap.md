# Tasks
- [x] Apply official logo, brand details, contact and neon blue theme.
- [x] Keep Juninho only with 100% commission.
- [x] Enforce opening hours, lunch closure and Sundays; test booking flow.