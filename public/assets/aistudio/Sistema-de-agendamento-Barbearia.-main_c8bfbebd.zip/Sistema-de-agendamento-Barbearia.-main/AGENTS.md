<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep shop identity and opening-hours validation centralized in the store; booking UI and appointment creation share the same rules to prevent closed-hours reservations.
- Reuse BrandLogo for shop headers and load the uploaded logo through its CDN asset pointer to keep identity consistent.
