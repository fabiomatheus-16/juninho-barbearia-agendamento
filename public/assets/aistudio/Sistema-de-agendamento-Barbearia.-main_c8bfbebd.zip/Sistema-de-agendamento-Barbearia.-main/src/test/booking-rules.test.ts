import { describe, expect, it } from "vitest";
import { actions, buildWhatsappLink, isWithinOpeningHours, SHOP, TIME_SLOTS, useStore } from "@/lib/store";
import { renderHook } from "@testing-library/react";

describe("Junin booking rules", () => {
  it("opens at 08:00 and closes at 18:00", () => {
    expect(TIME_SLOTS[0]).toBe("08:00");
    expect(TIME_SLOTS.at(-1)).toBe("17:30");
    expect(isWithinOpeningHours("2026-10-19", "18:00", 30)).toBe(false);
    expect(isWithinOpeningHours("2026-10-19", "17:30", 50)).toBe(false);
  });
  it("blocks lunch from 12:00 to 14:00 including overlapping services", () => {
    expect(TIME_SLOTS).not.toContain("12:00");
    expect(TIME_SLOTS).not.toContain("13:30");
    expect(isWithinOpeningHours("2026-10-19", "11:30", 50)).toBe(false);
    expect(isWithinOpeningHours("2026-10-19", "11:30", 30)).toBe(true);
    expect(isWithinOpeningHours("2026-10-19", "14:00", 50)).toBe(true);
  });
  it("blocks Sundays and rejects appointments without a valid service", () => {
    expect(isWithinOpeningHours("2026-10-25", "09:00", 30)).toBe(false);
    expect(isWithinOpeningHours("2026-10-24", "09:00", 30)).toBe(true);
    expect(() => actions.addAppointment({ serviceId: "inexistente", barberId: "b1", date: "2026-10-24", time: "09:00", clientName: "Teste", clientPhone: "84994571579" })).toThrow();
  });
  it("keeps Juninho as the sole barber with 100 percent commission", () => {
    const { result } = renderHook(() => useStore((s) => s.barbers));
    expect(result.current).toHaveLength(1);
    expect(result.current[0]).toMatchObject({ name: "Juninho", commission: 100 });
  });
  it("targets the supplied Brazilian WhatsApp number", () => {
    expect(buildWhatsappLink(SHOP.whatsapp, "Olá")).toBe("https://wa.me/5584994571579?text=Ol%C3%A1");
  });
});