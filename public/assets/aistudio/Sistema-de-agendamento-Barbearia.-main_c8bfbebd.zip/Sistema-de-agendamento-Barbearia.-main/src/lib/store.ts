import { useSyncExternalStore } from "react";
import { supabase } from "@/integrations/supabase/client";

export type Service = { id: string; name: string; price: number; duration: number };
export type Barber = { id: string; name: string; specialty: string; commission: number; active: boolean };
export type Status = "agendado" | "concluido" | "cancelado" | "faltou";
export type Appointment = {
  id: string;
  serviceId: string;
  barberId: string;
  date: string; // yyyy-mm-dd
  time: string; // HH:mm
  clientName: string;
  clientPhone: string;
  status: Status;
  createdAt: string;
};

export const SHOP = {
  name: "Junin Barbeiro",
  tagline: "Barbearia clássica, corte moderno",
  whatsapp: "5584994571579",
  address: "",
  founded: 2021,
  hours: "Segunda a Sábado · 08h–12h e 14h–18h",
};

export const todayISO = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

export const TIME_SLOTS = (() => {
  const s: string[] = [];
  for (let h = 8; h < 18; h++) {
    if (h === 12 || h === 13) continue;
    s.push(`${String(h).padStart(2, "0")}:00`, `${String(h).padStart(2, "0")}:30`);
  }
  return s;
})();

export function isOpenDate(date: string) {
  const day = new Date(date + "T12:00").getDay();
  return !Number.isNaN(day) && day !== 0;
}

export function isWithinOpeningHours(date: string, time: string, duration: number) {
  if (!isOpenDate(date) || !TIME_SLOTS.includes(time) || duration <= 0) return false;
  const [h, m] = time.split(":").map(Number);
  if (h === undefined || m === undefined) return false;
  const start = h * 60 + m;
  return (start >= 480 && start + duration <= 720) || (start >= 840 && start + duration <= 1080);
}

type State = { services: Service[]; servicesLoaded: boolean; barbers: Barber[]; appointments: Appointment[] };

const uid = () => Math.random().toString(36).slice(2, 10);
const t = todayISO();

let state: State = {
  services: [],
  servicesLoaded: false,
  barbers: [
    { id: "b1", name: "Juninho", specialty: "Corte & barba", commission: 100, active: true },
  ],
  appointments: [
    { id: uid(), serviceId: "s1", barberId: "b1", date: t, time: "09:00", clientName: "João Pereira", clientPhone: "85988887777", status: "concluido", createdAt: t },
    { id: uid(), serviceId: "s3", barberId: "b1", date: t, time: "10:00", clientName: "Marcos Silva", clientPhone: "85977776666", status: "agendado", createdAt: t },
    { id: uid(), serviceId: "s2", barberId: "b1", date: t, time: "11:30", clientName: "Pedro Rocha", clientPhone: "85966665555", status: "agendado", createdAt: t },
    { id: uid(), serviceId: "s1", barberId: "b1", date: t, time: "14:00", clientName: "Lucas Martins", clientPhone: "85955554444", status: "cancelado", createdAt: t },
    { id: uid(), serviceId: "s3", barberId: "b1", date: t, time: "16:30", clientName: "André Souza", clientPhone: "85944443333", status: "agendado", createdAt: t },
  ],
};

const listeners = new Set<() => void>();
const set = (fn: (s: State) => State) => {
  state = fn(state);
  listeners.forEach((l) => l());
};

export function useStore<T>(sel: (s: State) => T): T {
  return useSyncExternalStore(
    (l) => (listeners.add(l), () => listeners.delete(l)),
    () => sel(state),
    () => sel(state),
  );
}

export const actions = {
  addAppointment(a: Omit<Appointment, "id" | "status" | "createdAt">) {
    const service = state.services.find((s) => s.id === a.serviceId);
    if (!service || !isWithinOpeningHours(a.date, a.time, service.duration)) {
      throw new Error("Escolha um horário dentro do funcionamento da barbearia.");
    }
    const appt: Appointment = { ...a, id: uid(), status: "agendado", createdAt: todayISO() };
    set((s) => ({ ...s, appointments: [...s.appointments, appt] }));
    return appt;
  },
  setStatus(id: string, status: Status) {
    set((s) => ({ ...s, appointments: s.appointments.map((a) => (a.id === id ? { ...a, status } : a)) }));
  },
  async saveService(svc: Omit<Service, "id"> & { id?: string }) {
    const row = { name: svc.name, price: svc.price, duration: svc.duration };
    const { error } = svc.id
      ? await supabase.from("services").update(row).eq("id", svc.id)
      : await supabase.from("services").insert({ ...row, sort_order: state.services.length + 1 });
    if (error) throw new Error("Não foi possível salvar o serviço. Tente novamente.");
    await loadServices();
  },
  async deleteService(id: string) {
    const { error } = await supabase.from("services").delete().eq("id", id);
    if (error) throw new Error("Não foi possível excluir o serviço. Tente novamente.");
    await loadServices();
  },
  saveBarber(b: Omit<Barber, "id"> & { id?: string }) {
    set((s) => ({
      ...s,
      barbers: b.id ? s.barbers.map((x) => (x.id === b.id ? (b as Barber) : x)) : [...s.barbers, { ...b, id: uid() }],
    }));
  },
  deleteBarber(id: string) {
    set((s) => ({ ...s, barbers: s.barbers.filter((x) => x.id !== id) }));
  },
};

export async function loadServices() {
  const { data, error } = await supabase.from("services").select("id, name, price, duration").order("sort_order").order("name");
  if (!error && data) {
    set((s) => ({
      ...s,
      services: data.map((r) => ({ id: r.id, name: r.name, price: Number(r.price), duration: r.duration })),
      servicesLoaded: true,
    }));
  }
}

export function subscribeServices() {
  const channel = supabase
    .channel("services-changes")
    .on("postgres_changes", { event: "*", schema: "public", table: "services" }, () => {
      void loadServices();
    })
    .subscribe();
  return () => {
    supabase.removeChannel(channel);
  };
}

export const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
export const initials = (n: string) => n.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();

export function takenSlots(appts: Appointment[], barberId: string, date: string) {
  return new Set(appts.filter((a) => a.barberId === barberId && a.date === date && a.status !== "cancelado").map((a) => a.time));
}

export function buildWhatsappLink(phone: string, msg: string) {
  return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
}
