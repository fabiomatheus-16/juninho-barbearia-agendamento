import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";
import logoAsset from "@/assets/junin-logo.jpeg.asset.json";

export function BrandLogo({ className }: { className?: string }) {
  return <img src={logoAsset.url} alt="Junin Barbeiro" className={cn("size-12 shrink-0 rounded-full object-cover", className)} />;
}

type BtnVariant = "gold" | "outline" | "ghost" | "success" | "danger";
const variants: Record<BtnVariant, string> = {
  gold: "bg-gold text-primary-foreground shadow-gold font-bold",
  outline: "border border-border bg-card text-foreground",
  ghost: "text-muted-foreground hover:text-foreground",
  success: "bg-success/15 text-success border border-success/30",
  danger: "bg-destructive/15 text-destructive border border-destructive/30",
};

export function Btn({ variant = "gold", className, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: BtnVariant }) {
  return (
    <button
      {...p}
      className={cn(
        "inline-flex min-h-12 items-center justify-center gap-2 rounded-xl px-5 text-sm transition active:scale-[0.97] disabled:opacity-40 disabled:pointer-events-none",
        variants[variant],
        className,
      )}
    />
  );
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cn("rounded-2xl border border-border bg-card p-4", className)}>{children}</div>;
}

export function Field({ label, ...p }: InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
      <input
        {...p}
        className="h-12 w-full rounded-xl border border-input bg-secondary px-4 text-base text-foreground outline-none placeholder:text-muted-foreground focus:border-ring"
      />
    </label>
  );
}

export function Avatar({ name, className }: { name: string; className?: string }) {
  const ini = name.split(" ").map((p) => p[0]).slice(0, 2).join("").toUpperCase();
  return (
    <div className={cn("flex size-12 shrink-0 items-center justify-center rounded-full bg-accent font-display text-lg font-semibold text-accent-foreground ring-1 ring-primary/30", className)}>
      {ini}
    </div>
  );
}

export function PageHeader({ eyebrow, title, right }: { eyebrow: string; title: string; right?: ReactNode }) {
  return (
    <header className="flex flex-wrap items-center justify-between gap-3 px-5 pb-4 pt-6">
      <BrandLogo />
      <div className="min-w-0 flex-1">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">{eyebrow}</p>
        <h1 className="mt-1 text-3xl font-semibold">{title}</h1>
      </div>
      {right}
    </header>
  );
}

export function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <Card className="p-4">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="mt-1 font-display text-2xl font-semibold text-primary">{value}</p>
      {hint && <p className="mt-0.5 text-xs text-muted-foreground">{hint}</p>}
    </Card>
  );
}
