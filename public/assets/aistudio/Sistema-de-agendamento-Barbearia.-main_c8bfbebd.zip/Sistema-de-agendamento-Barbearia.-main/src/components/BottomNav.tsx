import { Link } from "@tanstack/react-router";
import { CalendarPlus, Home, LayoutDashboard, Scissors } from "lucide-react";

const items = [
  { to: "/", label: "Início", icon: Home },
  { to: "/agendar", label: "Agendar", icon: CalendarPlus },
  { to: "/barbeiro", label: "Barbeiro", icon: Scissors },
  { to: "/admin", label: "Admin", icon: LayoutDashboard },
] as const;

export function BottomNav() {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/90 backdrop-blur-lg pb-[env(safe-area-inset-bottom)]">
      <div className="mx-auto grid max-w-md grid-cols-4">
        {items.map(({ to, label, icon: Icon }) => (
          <Link
            key={to}
            to={to}
            activeOptions={{ exact: to === "/" }}
            className="flex min-h-16 flex-col items-center justify-center gap-1 text-[11px] font-semibold text-muted-foreground data-[status=active]:text-primary"
          >
            <Icon className="size-5" />
            {label}
          </Link>
        ))}
      </div>
    </nav>
  );
}
