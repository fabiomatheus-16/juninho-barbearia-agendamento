import { createFileRoute, Link } from "@tanstack/react-router";
import { Clock, MessageCircle, Star } from "lucide-react";
import { SHOP, brl, buildWhatsappLink, useStore } from "@/lib/store";
import { BrandLogo, Card } from "@/components/ui-kit";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Junin Barbeiro — Agende seu corte" },
      { name: "description", content: "Agende corte e barba com Juninho, de segunda a sábado, das 08h às 12h e das 14h às 18h." },
      { property: "og:title", content: "Junin Barbeiro — Agende seu corte" },
      { property: "og:description", content: "Agendamento online de corte e barba em poucos toques." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

function Index() {
  const { services, servicesLoaded } = useStore((s) => s);
  return (
    <div>
      <section className="flex flex-col items-center px-6 pb-6 pt-6 text-center">
        <BrandLogo className="size-40 ring-1 ring-primary/30" />
        <p className="mt-4 text-xs font-semibold uppercase tracking-[0.3em] text-primary">Barbearia desde {SHOP.founded}</p>
        <h1 className="mt-2 text-5xl font-semibold leading-none">{SHOP.name}</h1>
        <p className="mt-3 text-muted-foreground">{SHOP.tagline}</p>
        <div className="mt-4 flex items-center gap-1 text-sm text-primary">
          {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="size-4 fill-current" />)}
          <span className="ml-1 text-muted-foreground">4,9 · 820 avaliações</span>
        </div>
        <Link to="/agendar" className="mt-8 inline-flex min-h-14 w-full max-w-xs items-center justify-center rounded-2xl bg-gold text-base font-bold text-primary-foreground shadow-gold active:scale-[0.97] transition">
          Agendar Horário
        </Link>
      </section>

      <section className="space-y-3 px-5">
        <div className="flex items-center gap-3"><Clock className="size-5 shrink-0 text-primary" /><div className="text-sm"><p>{SHOP.hours}</p><p className="text-xs text-muted-foreground">Domingo fechado</p></div></div>
        <a href={buildWhatsappLink(SHOP.whatsapp, `Olá, ${SHOP.name}! Gostaria de agendar um horário.`)} target="_blank" rel="noreferrer" className="flex min-h-12 items-center gap-3 text-primary"><MessageCircle className="size-5" /><span className="text-sm">WhatsApp · (84) 99457-1579</span></a>
      </section>

      <section className="px-5 pt-8">
        <h2 className="mb-3 text-xl font-semibold">Serviços</h2>
        <div className="space-y-2">
          {!servicesLoaded && <p className="py-4 text-center text-sm text-muted-foreground">Carregando serviços...</p>}
          {services.map((s) => (
            <Card key={s.id} className="flex items-center justify-between">
              <div><p className="font-semibold">{s.name}</p><p className="text-xs text-muted-foreground">{s.duration} min</p></div>
              <p className="font-display text-lg text-primary">{brl(s.price)}</p>
            </Card>
          ))}
        </div>
      </section>
    </div>
  );
}
