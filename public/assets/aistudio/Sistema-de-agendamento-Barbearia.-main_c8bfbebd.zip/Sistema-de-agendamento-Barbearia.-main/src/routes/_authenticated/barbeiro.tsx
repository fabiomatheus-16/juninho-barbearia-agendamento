import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Check, Phone, UserX } from "lucide-react";
import { actions, brl, todayISO, useStore, type Appointment, type Status } from "@/lib/store";
import { Avatar, Btn, Card, PageHeader, Stat } from "@/components/ui-kit";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/barbeiro")({
  head: () => ({
    meta: [
      { title: "Painel do Barbeiro — Junin Barbeiro" },
      { name: "description", content: "Agenda do dia, status dos atendimentos e faturamento do barbeiro." },
      { property: "og:title", content: "Painel do Barbeiro — Junin Barbeiro" },
      { property: "og:description", content: "Sua agenda e comissão do dia em um só lugar." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: BarberPanel,
});

const STATUS: Record<Status, { label: string; cls: string }> = {
  agendado: { label: "Agendado", cls: "bg-primary/15 text-primary" },
  concluido: { label: "Concluído", cls: "bg-success/15 text-success" },
  cancelado: { label: "Cancelado", cls: "bg-muted text-muted-foreground" },
  faltou: { label: "Faltou", cls: "bg-destructive/15 text-destructive" },
};

function BarberPanel() {
  const { barbers, services, appointments } = useStore((s) => s);
  const [barberId, setBarberId] = useState(barbers[0]?.id);
  const barber = barbers.find((b) => b.id === barberId);
  const today = todayISO();
  const list = appointments.filter((a) => a.barberId === barberId && a.date === today).sort((a, b) => a.time.localeCompare(b.time));
  const svc = (id: string) => services.find((s) => s.id === id);
  const revenue = list.filter((a) => a.status === "concluido").reduce((n, a) => n + (svc(a.serviceId)?.price ?? 0), 0);
  const commission = revenue * ((barber?.commission ?? 0) / 100);
  const morning = list.filter((a) => a.time < "12:00");
  const afternoon = list.filter((a) => a.time >= "12:00");

  return (
    <div>
      <PageHeader eyebrow={new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "short" })} title="Minha agenda" />
      <div className="-mt-1 flex gap-2 overflow-x-auto px-5 pb-4">
        {barbers.map((b) => (
          <button key={b.id} onClick={() => setBarberId(b.id)} className={cn("flex shrink-0 items-center gap-2 rounded-full border py-1.5 pl-1.5 pr-4 text-sm font-semibold", b.id === barberId ? "border-primary bg-accent text-accent-foreground" : "border-border text-muted-foreground")}>
            <Avatar name={b.name} className="size-8 text-xs" />{b.name.split(" ")[0]}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-3 px-5">
        <Stat label="Faturado hoje" value={brl(revenue)} hint={`${list.filter((a) => a.status === "concluido").length} concluídos`} />
        <Stat label={`Comissão (${barber?.commission ?? 0}%)`} value={brl(commission)} hint={`${list.filter((a) => a.status === "agendado").length} pendentes`} />
      </div>

      <div className="space-y-6 px-5 pt-6">
        <Block title="Manhã" items={morning} svc={svc} />
        <Block title="Tarde" items={afternoon} svc={svc} />
        {list.length === 0 && <p className="py-10 text-center text-muted-foreground">Nenhum atendimento hoje.</p>}
      </div>
    </div>
  );
}

function Block({ title, items, svc }: { title: string; items: Appointment[]; svc: (id: string) => { name: string; price: number; duration: number } | undefined }) {
  if (!items.length) return null;
  return (
    <section>
      <h2 className="mb-3 text-lg font-semibold">{title}</h2>
      <ol className="relative space-y-3 border-l border-border pl-5">
        {items.map((a) => {
          const s = svc(a.serviceId);
          const st = STATUS[a.status];
          return (
            <li key={a.id} className="relative">
              <span className={cn("absolute -left-[26px] top-5 size-3 rounded-full ring-4 ring-background", a.status === "concluido" ? "bg-success" : a.status === "agendado" ? "bg-primary" : "bg-muted-foreground")} />
              <Card className={cn(a.status === "cancelado" && "opacity-60")}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <p className="font-display text-xl text-primary">{a.time}</p>
                    <p className="mt-1 font-semibold">{a.clientName}</p>
                    <p className="text-xs text-muted-foreground">{s?.name} · {s?.duration} min · {brl(s?.price ?? 0)}</p>
                  </div>
                  <span className={cn("rounded-full px-2.5 py-1 text-[11px] font-bold", st.cls)}>{st.label}</span>
                </div>
                {a.status === "agendado" && (
                  <div className="mt-3 grid grid-cols-[1fr_1fr_auto] gap-2">
                    <Btn variant="success" className="min-h-11" onClick={() => actions.setStatus(a.id, "concluido")}><Check className="size-4" />Concluído</Btn>
                    <Btn variant="danger" className="min-h-11" onClick={() => actions.setStatus(a.id, "faltou")}><UserX className="size-4" />Faltou</Btn>
                    <a aria-label="Ligar" href={`https://wa.me/55${a.clientPhone.replace(/\D/g, "")}`} target="_blank" rel="noreferrer" className="flex size-11 items-center justify-center rounded-xl border border-border"><Phone className="size-4" /></a>
                  </div>
                )}
              </Card>
            </li>
          );
        })}
      </ol>
    </section>
  );
}
