import { createFileRoute, Outlet, redirect, useNavigate } from "@tanstack/react-router";
import { LogOut } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async ({ location }) => {
    const { data } = await supabase.auth.getUser();
    if (!data.user) throw redirect({ to: "/auth", search: { redirect: location.pathname } });
    return { user: data.user };
  },
  component: Layout,
});

function Layout() {
  const { user } = Route.useRouteContext();
  const navigate = useNavigate();
  return (
    <>
      <div className="flex items-center justify-between gap-2 px-5 pt-4 text-xs text-muted-foreground">
        <span className="truncate">{user.email}</span>
        <button
          onClick={async () => {
            await supabase.auth.signOut();
            navigate({ to: "/auth", search: { redirect: "/barbeiro" }, replace: true });
          }}
          className="flex items-center gap-1 font-semibold text-primary"
        >
          <LogOut className="size-3.5" /> Sair
        </button>
      </div>
      <Outlet />
    </>
  );
}
