import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Pencil, Plus, Trash2, X } from "lucide-react";
import { actions, brl, useStore, type Barber, type Service } from "@/lib/store";
import { Avatar, Btn, Card, Field, PageHeader, Stat } from "@/components/ui-kit";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Gestão da Barbearia — Junin Barbeiro" },
      { name: "description", content: "Métricas do mês, serviços e equipe de barbeiros." },
      { property: "og:title", content: "Gestão da Barbearia — Junin Barbeiro" },
      { property: "og:description", content: "Painel administrativo da barbearia." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Admin,
});

const TABS = ["Visão geral", "Serviços", "Barbeiros"] as const;

function Admin() {
  const [tab, setTab] = useState<(typeof TABS)[number]>("Visão geral");
  return (
    <div>
      <PageHeader eyebrow="Administração" title="Gestão" />
      <div className="mx-5 mb-5 grid grid-cols-3 gap-1 rounded-xl bg-muted p-1">
        {TABS.map((t) => (
          <button key={t} onClick={() => setTab(t)} className={cn("min-h-10 rounded-lg text-xs font-bold transition", t === tab ? "bg-card text-primary" : "text-muted-foreground")}>{t}</button>
        ))}
      </div>
      <div className="px-5">
        {tab === "Visão geral" && <Overview />}
        {tab === "Serviços" && <Services />}
        {tab === "Barbeiros" && <Barbers />}
      </div>
    </div>
  );
}

function Overview() {
  const { appointments, services, barbers } = useStore((s) => s);
  const ym = new Date().toISOString().slice(0, 7);
  const month = appointments.filter((a) => a.date.startsWith(ym));
  const price = (id: string) => services.find((s) => s.id === id)?.price ?? 0;
  const revenue = month.filter((a) => a.status === "concluido").reduce((n, a) => n + price(a.serviceId), 0);
  const newClients = new Set(month.map((a) => a.clientPhone.replace(/\D/g, ""))).size;
  return (
    <div className="space-y-3">
      <Card className="bg-hero">
        <p className="text-xs text-muted-foreground">Faturamento do mês</p>
        <p className="mt-1 font-display text-4xl font-semibold text-primary">{brl(revenue)}</p>
        <p className="mt-1 text-xs capitalize text-muted-foreground">{new Date().toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</p>
      </Card>
      <div className="grid grid-cols-2 gap-3">
        <Stat label="Agendamentos" value={String(month.length)} hint={`${month.filter((a) => a.status === "agendado").length} a realizar`} />
        <Stat label="Novos clientes" value={String(newClients)} hint="no mês" />
      </div>
      <h2 className="pt-3 text-lg font-semibold">Por barbeiro</h2>
      {barbers.map((b) => {
        const mine = month.filter((a) => a.barberId === b.id && a.status === "concluido");
        return (
          <Card key={b.id} className="flex items-center gap-3">
            <Avatar name={b.name} className="size-10 text-sm" />
            <div className="flex-1"><p className="font-semibold">{b.name}</p><p className="text-xs text-muted-foreground">{mine.length} atendimentos</p></div>
            <p className="font-display text-primary">{brl(mine.reduce((n, a) => n + price(a.serviceId), 0))}</p>
          </Card>
        );
      })}
    </div>
  );
}

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end bg-background/70 backdrop-blur-sm animate-in fade-in" onClick={onClose}>
      <div className="mx-auto w-full max-w-md rounded-t-3xl border-t border-border bg-card p-5 pb-8 animate-in slide-in-from-bottom" onClick={(e) => e.stopPropagation()}>
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-xl font-semibold">{title}</h3>
          <button aria-label="Fechar" onClick={onClose} className="flex size-10 items-center justify-center rounded-full"><X className="size-5" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Services() {
  const { services, servicesLoaded } = useStore((s) => s);
  const [edit, setEdit] = useState<Partial<Service> | null>(null);
  const [removing, setRemoving] = useState<Service | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!edit || saving) return;
    const name = (edit.name ?? "").trim();
    if (!name) return setError("Informe o nome do serviço.");
    if (!edit.price || edit.price <= 0) return setError("Informe um preço maior que zero.");
    if (!edit.duration || edit.duration < 5) return setError("A duração mínima é de 5 minutos.");
    setSaving(true);
    try {
      await actions.saveService({ ...(edit.id ? { id: edit.id } : {}), name, price: edit.price, duration: edit.duration });
      setEdit(null);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível salvar o serviço.");
    } finally {
      setSaving(false);
    }
  }

  async function confirmRemove() {
    if (!removing || saving) return;
    setSaving(true);
    try {
      await actions.deleteService(removing.id);
      setRemoving(null);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Não foi possível excluir o serviço.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-2">
      <Btn className="w-full" onClick={() => { setEdit({ name: "", price: 0, duration: 30 }); setError(null); }}><Plus className="size-4" />Novo serviço</Btn>
      {!servicesLoaded && <p className="py-6 text-center text-sm text-muted-foreground">Carregando serviços...</p>}
      {servicesLoaded && services.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">Nenhum serviço cadastrado.</p>}
      {services.map((s) => (
        <Card key={s.id} className="flex items-center gap-3">
          <div className="flex-1"><p className="font-semibold">{s.name}</p><p className="text-xs text-muted-foreground">{s.duration} min · {brl(s.price)}</p></div>
          <IconBtn label="Editar" onClick={() => { setEdit(s); setError(null); }}><Pencil className="size-4" /></IconBtn>
          <IconBtn label="Excluir" onClick={() => setRemoving(s)}><Trash2 className="size-4 text-destructive" /></IconBtn>
        </Card>
      ))}
      {edit && (
        <Sheet title={edit.id ? "Editar serviço" : "Novo serviço"} onClose={() => { setEdit(null); setError(null); }}>
          <form className="space-y-3" onSubmit={save}>
            <Field label="Nome" value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            <div className="grid grid-cols-2 gap-3">
              <Field label="Preço (R$)" type="number" min={0} inputMode="decimal" value={edit.price} onChange={(e) => setEdit({ ...edit, price: Number(e.target.value) })} />
              <Field label="Duração (min)" type="number" min={5} step={5} inputMode="numeric" value={edit.duration} onChange={(e) => setEdit({ ...edit, duration: Number(e.target.value) })} />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
            <Btn type="submit" disabled={saving} className="w-full">{saving ? "Salvando..." : "Salvar"}</Btn>
          </form>
        </Sheet>
      )}
      {removing && (
        <Sheet title="Excluir serviço" onClose={() => setRemoving(null)}>
          <p className="text-sm text-muted-foreground">
            Excluir <span className="font-semibold text-foreground">{removing.name}</span>? Ele deixará de aparecer na página de agendamento dos clientes.
          </p>
          {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
          <div className="mt-4 grid grid-cols-2 gap-3">
            <Btn variant="outline" onClick={() => { setRemoving(null); setError(null); }}>Cancelar</Btn>
            <Btn variant="danger" disabled={saving} onClick={confirmRemove}>{saving ? "Excluindo..." : "Excluir"}</Btn>
          </div>
        </Sheet>
      )}
    </div>
  );
}

function Barbers() {
  const barbers = useStore((s) => s.barbers);
  const [edit, setEdit] = useState<Partial<Barber> | null>(null);
  return (
    <div className="space-y-2">
      <Btn className="w-full" onClick={() => setEdit({ name: "", specialty: "", commission: 50, active: true })}><Plus className="size-4" />Novo barbeiro</Btn>
      {barbers.map((b) => (
        <Card key={b.id} className={cn("flex items-center gap-3", !b.active && "opacity-50")}>
          <Avatar name={b.name} />
          <div className="flex-1"><p className="font-semibold">{b.name}</p><p className="text-xs text-muted-foreground">{b.specialty} · {b.commission}%{!b.active && " · inativo"}</p></div>
          <IconBtn label="Editar" onClick={() => setEdit(b)}><Pencil className="size-4" /></IconBtn>
          <IconBtn label="Excluir" onClick={() => actions.deleteBarber(b.id)}><Trash2 className="size-4 text-destructive" /></IconBtn>
        </Card>
      ))}
      {edit && (
        <Sheet title={edit.id ? "Editar barbeiro" : "Novo barbeiro"} onClose={() => setEdit(null)}>
          <form className="space-y-3" onSubmit={(e) => { e.preventDefault(); actions.saveBarber(edit as Barber); setEdit(null); }}>
            <Field label="Nome" required value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
            <Field label="Especialidade" value={edit.specialty} onChange={(e) => setEdit({ ...edit, specialty: e.target.value })} />
            <Field label="Comissão (%)" type="number" min={0} max={100} required value={edit.commission} onChange={(e) => setEdit({ ...edit, commission: Number(e.target.value) })} />
            <label className="flex min-h-12 items-center justify-between rounded-xl border border-border px-4">
              <span className="text-sm font-semibold">Ativo para agendamento</span>
              <input type="checkbox" className="size-5 accent-primary" checked={edit.active} onChange={(e) => setEdit({ ...edit, active: e.target.checked })} />
            </label>
            <Btn type="submit" className="w-full">Salvar</Btn>
          </form>
        </Sheet>
      )}
    </div>
  );
}

function IconBtn({ label, onClick, children }: { label: string; onClick: () => void; children: React.ReactNode }) {
  return <button aria-label={label} onClick={onClick} className="flex size-11 items-center justify-center rounded-xl border border-border">{children}</button>;
}
