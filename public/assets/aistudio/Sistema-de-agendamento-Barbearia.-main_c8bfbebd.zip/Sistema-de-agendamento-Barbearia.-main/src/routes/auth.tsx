import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Btn, Card, Field, PageHeader } from "@/components/ui-kit";

export const Route = createFileRoute("/auth")({
  validateSearch: (s: Record<string, unknown>) => ({
    redirect: typeof s["redirect"] === "string" && s["redirect"].startsWith("/") ? s["redirect"] : "/barbeiro",
  }),
  head: () => ({
    meta: [
      { title: "Acesso da equipe — Junin Barbeiro" },
      { name: "description", content: "Login da equipe para acessar agenda e configurações da barbearia." },
      { property: "og:title", content: "Acesso da equipe — Junin Barbeiro" },
      { property: "og:description", content: "Login da equipe para acessar agenda e configurações." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const { redirect } = Route.useSearch();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function submit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMsg(null);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) return setMsg("E-mail ou senha incorretos.");
    navigate({ to: redirect, replace: true });
  }

  return (
    <div>
      <PageHeader eyebrow="Acesso restrito" title="Área da equipe" />
      <div className="px-5">
        <Card>
          <form onSubmit={submit} className="space-y-4">
            <Field label="E-mail" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
            <Field label="Senha" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
            {msg && <p className="text-sm text-destructive">{msg}</p>}
            <Btn type="submit" disabled={loading} className="w-full">
              {loading ? "Aguarde..." : "Entrar"}
            </Btn>
          </form>
          <p className="mt-4 text-center text-xs text-muted-foreground">
            Acesso exclusivo da equipe. Clientes agendam sem login.
          </p>
        </Card>
      </div>
    </div>
  );
}
