import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft, Check, ChevronLeft, ChevronRight, MessageCircle } from "lucide-react";
import { SHOP, TIME_SLOTS, actions, brl, buildWhatsappLink, isOpenDate, isWithinOpeningHours, takenSlots, todayISO, useStore, type Appointment } from "@/lib/store";
import { Avatar, BrandLogo, Btn, Card, Field } from "@/components/ui-kit";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/agendar")({
  head: () => ({
    meta: [
      { title: "Agendar horário — Junin Barbeiro" },
      { name: "description", content: "Escolha serviço, barbeiro, data e horário e confirme pelo WhatsApp." },
      { property: "og:title", content: "Agendar horário — Junin Barbeiro" },
      { property: "og:description", content: "Agende seu corte em 4 passos rápidos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Booking,
});

const iso = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
const fmtDate = (s: string) => new Date(s + "T12:00").toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long" });
const STEPS = ["Serviço", "Barbeiro", "Horário", "Seus dados"];

function Booking() {
  const { services, servicesLoaded, barbers, appointments } = useStore((s) => s);
  const [step, setStep] = useState(0);
  const [serviceId, setServiceId] = useState<string>();
  const [barberId, setBarberId] = useState<string>();
  const [date, setDate] = useState(todayISO());
  const [time, setTime] = useState<string>();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [done, setDone] = useState<Appointment>();

  const service = services.find((s) => s.id === serviceId);
  const barber = barbers.find((b) => b.id === barberId);
  const taken = useMemo(() => (barberId ? takenSlots(appointments, barberId, date) : new Set<string>()), [appointments, barberId, date]);

  const canNext = [!!serviceId, !!barberId, !!time, name.trim().length > 1 && phone.replace(/\D/g, "").length >= 10][step];

  const next = () => {
    if (step < 3) return setStep(step + 1);
    if (!serviceId || !barberId || !time || !service || !isWithinOpeningHours(date, time, service.duration)) return;
    setDone(actions.addAppointment({ serviceId, barberId, date, time, clientName: name.trim(), clientPhone: phone }));
  };

  if (done && service && barber) {
    const msg = `Olá, ${SHOP.name}! Acabei de agendar:\n\n✂️ ${service.name} (${brl(service.price)})\n💈 Barbeiro: ${barber.name}\n📅 ${fmtDate(done.date)} às ${done.time}\n👤 ${done.clientName} — ${done.clientPhone}\n\nAguardo a confirmação!`;
    return (
      <div className="flex flex-col items-center px-6 pt-16 text-center">
        <div className="flex size-20 items-center justify-center rounded-full bg-success/15 ring-1 ring-success/40">
          <Check className="size-10 text-success" />
        </div>
        <h1 className="mt-6 text-3xl font-semibold">Horário reservado!</h1>
        <p className="mt-2 text-muted-foreground">Envie a confirmação para a barbearia garantir sua vaga.</p>
        <Card className="mt-6 w-full space-y-2 text-left text-sm">
          <Row k="Serviço" v={service.name} />
          <Row k="Barbeiro" v={barber.name} />
          <Row k="Data" v={fmtDate(done.date)} />
          <Row k="Horário" v={done.time} />
          <Row k="Valor" v={brl(service.price)} />
        </Card>
        <a href={buildWhatsappLink(SHOP.whatsapp, msg)} target="_blank" rel="noreferrer" className="mt-6 inline-flex min-h-14 w-full items-center justify-center gap-2 rounded-2xl bg-success text-base font-bold text-success-foreground active:scale-[0.97] transition">
          <MessageCircle className="size-5" /> Enviar confirmação no WhatsApp da Barbearia
        </a>
        <Btn variant="ghost" className="mt-3" onClick={() => { setDone(undefined); setStep(0); setServiceId(undefined); setBarberId(undefined); setTime(undefined); setName(""); setPhone(""); }}>
          Fazer outro agendamento
        </Btn>
      </div>
    );
  }

  return (
    <div className="flex min-h-[calc(100dvh-4rem)] flex-col">
      <div className="sticky top-0 z-10 bg-background/90 px-5 pb-3 pt-5 backdrop-blur">
        <div className="flex items-center gap-3">
          <BrandLogo />
          {step > 0 && <button aria-label="Voltar" onClick={() => setStep(step - 1)} className="-ml-2 flex size-10 items-center justify-center rounded-full text-muted-foreground"><ArrowLeft className="size-5" /></button>}
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-primary">Passo {step + 1} de 4</p>
            <h1 className="text-2xl font-semibold">{STEPS[step]}</h1>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-4 gap-1.5">
          {STEPS.map((_, i) => <div key={i} className={cn("h-1 rounded-full", i <= step ? "bg-primary" : "bg-muted")} />)}
        </div>
      </div>

      <div className="flex-1 space-y-3 px-5 pb-32 pt-2">
        {step === 0 && !servicesLoaded && <p className="py-6 text-center text-sm text-muted-foreground">Carregando serviços...</p>}
        {step === 0 && servicesLoaded && services.length === 0 && <p className="py-6 text-center text-sm text-muted-foreground">Nenhum serviço disponível no momento.</p>}
        {step === 0 && services.map((s) => (
          <Select key={s.id} active={s.id === serviceId} onClick={() => setServiceId(s.id)}>
            <div className="flex-1"><p className="font-semibold">{s.name}</p><p className="text-xs text-muted-foreground">{s.duration} min</p></div>
            <p className="font-display text-lg text-primary">{brl(s.price)}</p>
          </Select>
        ))}

        {step === 1 && barbers.filter((b) => b.active).map((b) => (
          <Select key={b.id} active={b.id === barberId} onClick={() => { setBarberId(b.id); setTime(undefined); }}>
            <Avatar name={b.name} />
            <div className="flex-1"><p className="font-semibold">{b.name}</p><p className="text-xs text-muted-foreground">{b.specialty}</p></div>
          </Select>
        ))}

        {step === 2 && (
          <>
            <MiniCalendar value={date} onChange={(d) => { setDate(d); setTime(undefined); }} />
            <p className="pt-2 text-sm capitalize text-muted-foreground">{fmtDate(date)}</p>
            <div className="grid grid-cols-4 gap-2">
              {TIME_SLOTS.map((t) => {
                const past = date === todayISO() && t <= new Date().toTimeString().slice(0, 5);
                const off = taken.has(t) || past || !isWithinOpeningHours(date, t, service?.duration ?? 30);
                return (
                  <button key={t} disabled={off} onClick={() => setTime(t)}
                    className={cn("h-12 rounded-xl border text-sm font-semibold transition active:scale-95",
                      off ? "border-transparent bg-muted/40 text-muted-foreground/40 line-through" :
                      t === time ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card")}>
                    {t}
                  </button>
                );
              })}
            </div>
          </>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <Card className="space-y-1.5 text-sm">
              <Row k="Serviço" v={service?.name ?? ""} />
              <Row k="Barbeiro" v={barber?.name ?? ""} />
              <Row k="Quando" v={`${new Date(date + "T12:00").toLocaleDateString("pt-BR")} · ${time}`} />
              <Row k="Total" v={brl(service?.price ?? 0)} />
            </Card>
            <Field label="Nome" placeholder="Seu nome completo" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
            <Field label="WhatsApp" placeholder="(85) 99999-9999" inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} autoComplete="tel" />
          </div>
        )}
      </div>

      <div className="fixed inset-x-0 bottom-16 z-30 border-t border-border bg-background/95 px-5 py-3 backdrop-blur">
        <div className="mx-auto flex max-w-md items-center gap-3">
          {service && <div className="text-xs text-muted-foreground"><p>{service.name}</p><p className="font-display text-base text-primary">{brl(service.price)}</p></div>}
          <Btn className="flex-1" disabled={!canNext} onClick={next}>{step === 3 ? "Confirmar agendamento" : "Continuar"}</Btn>
        </div>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex justify-between gap-4"><span className="text-muted-foreground">{k}</span><span className="text-right font-semibold capitalize">{v}</span></div>;
}

function Select({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button onClick={onClick} className={cn("flex min-h-20 w-full items-center gap-4 rounded-2xl border bg-card p-4 text-left transition active:scale-[0.98]", active ? "border-primary ring-1 ring-primary" : "border-border")}>
      {children}
      <div className={cn("flex size-6 items-center justify-center rounded-full border", active ? "border-primary bg-primary" : "border-border")}>
        {active && <Check className="size-4 text-primary-foreground" />}
      </div>
    </button>
  );
}

function MiniCalendar({ value, onChange }: { value: string; onChange: (d: string) => void }) {
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const [month, setMonth] = useState(() => new Date(today.getFullYear(), today.getMonth(), 1));
  const first = month.getDay();
  const days = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const cells = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => i + 1)];
  const canPrev = month > new Date(today.getFullYear(), today.getMonth(), 1);
  return (
    <Card>
      <div className="mb-3 flex items-center justify-between">
        <button aria-label="Mês anterior" disabled={!canPrev} onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))} className="flex size-10 items-center justify-center rounded-full disabled:opacity-30"><ChevronLeft className="size-5" /></button>
        <p className="font-display text-lg capitalize">{month.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</p>
        <button aria-label="Próximo mês" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))} className="flex size-10 items-center justify-center rounded-full"><ChevronRight className="size-5" /></button>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-semibold text-muted-foreground">
        {["D", "S", "T", "Q", "Q", "S", "S"].map((d, i) => <div key={i} className="py-1">{d}</div>)}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {cells.map((d, i) => {
          if (!d) return <div key={i} />;
          const dt = new Date(month.getFullYear(), month.getMonth(), d);
          const key = iso(dt);
           const off = dt < today || !isOpenDate(key);
          return (
            <button key={i} disabled={off} onClick={() => onChange(key)}
              className={cn("aspect-square rounded-xl text-sm font-semibold transition", off ? "text-muted-foreground/30" : key === value ? "bg-primary text-primary-foreground" : "hover:bg-muted")}>
              {d}
            </button>
          );
        })}
      </div>
    </Card>
  );
}
