# 💈 Junin Barbeiro — Sistema SaaS de Agendamento

> Sistema web moderno de gestão e agendamento online desenvolvido sob medida para barbearias, focado em alta conversão, agilidade no atendimento mobile e autonomia para o administrador.

---

## 🚀 Sobre o Projeto

O **Junin Barbeiro** nasceu para resolver a dor de pequenos estabelecimentos que precisam de uma agenda digital limpa, rápida e sem burocracia para os clientes, combinada com um painel de controle administrativo seguro para o barbeiro gerenciar seus ganhos, comissões e serviços.

---

## ✨ Funcionalidades Principais

### 🌐 Fluxo do Cliente (Público)
* **Agendamento Rápido (Mobile-First):** Escolha de serviços, seleção do profissional (Juninho) e marcação de horário em poucos cliques.
* **Sem Burocracia:** O cliente não precisa criar senhas ou cadastros longos — basta informar o Nome e o WhatsApp
* **Integração Direta com WhatsApp:** Confirmação automática gerando um link direto para o WhatsApp da barbearia com a mensagem pronta dos detalhes do agendamento
* **Bloqueios Inteligentes:** O sistema impede automaticamente agendamentos aos domingos, no horário de almoço (12h às 14h) e em horários já passados

### 🔒 Painel Administrativo / Barbeiro (Privado e Seguro)
* **Acesso Restrito:** Área protegida por login exclusivo para o administrador gerenciar o negócio sem riscos de interferência externa.
* **Gestão de Serviços:** O admin pode adicionar, editar preços e remover serviços diretamente pelo painel.
* **Controle de Agenda Diária:** Visualização dividida em turnos (manhã e tarde) para marcar os cortes como "Concluído" ou "Não compareceu"[cite: 1].
* **Cálculo de Faturamento:** Acompanhamento em tempo real dos ganhos do dia/mês com base nos atendimentos finalizados.

---

## 🛠️ Tecnologias Utilizadas

* **Front-end:** Interface moderna desenvolvida com foco em dispositivos móveis (*mobile-first*), modo escuro (Dark Mode) estilizado com detalhes em **azul neon** e a identidade visual oficial da marca.
* **Banco de Dados & Nuvem:** Supabase (PostgreSQL) para persistência segura e em tempo real dos agendamentos e cadastros.
* **Hospedagem / Deploy:** Vercel / Netlify.

---

## 📋 Tabela de Serviços Oficiais

| Serviço | Preço |
| :--- | :--- |
| **Nevou + corte** | R$ 75,00 |
| **Reflexo alinhado + corte** | R$ 75,00 |
| **Corte navalhado** | R$ 20,00 |
| **Corte pigmentado** | R$ 35,00 |
| **Barba** | R$ 10,00 |

---

## 📞 Contato & Informações
* **Estabelecimento:** Junin Barbeiro
* **Ano de Fundação:** 2021
* **WhatsApp Oficial:** (84) 99457-1579
* **Horário de Funcionamento:** Segunda a Sábado, das 08:00 às 12:00 e das 14:00 às 18:00 (Fechado aos domingos)

---
*Desenvolvido com foco em alta performance e simplicidade.*
